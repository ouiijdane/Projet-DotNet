﻿using System;

namespace TP1_EX3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choix=0;
            string chaine = "faculte des sciences et techniques";
            do
            {
                Console.WriteLine("menu:");
                Console.WriteLine("1: saisir");
                Console.WriteLine("2: inverse");
                Console.WriteLine("3: mot");
                Console.WriteLine("tapez votre choix :");
                string strchoix = Console.ReadLine();
                choix = Int32.Parse(strchoix);
                if (choix == 1)
                {
                    Console.WriteLine("saisir une chaine");
                    chaine = Console.ReadLine();
                    Console.WriteLine(chaine);
                    Console.WriteLine("frappez une touche pour revenir au menu ");
                    Console.ReadKey();
                }
                else if (choix == 2)
                {
                    char[] c = chaine.ToCharArray();
                    string inverseChaine = " ";
                    for (int i = chaine.Length - 1; i >= 0; i--)
                    {
                        inverseChaine += c[i];
                    }
                    Console.WriteLine(inverseChaine);
                    Console.WriteLine("frappez une touche pour revenir au menu ");
                    Console.ReadKey();
                }
                else if (choix == 3)
                {
                    int nmbrDeMots = 0;
                    char[] cChaine = chaine.ToCharArray();
                    
                if (cChaine[0] != ' ')
                    
                        nmbrDeMots++;
                   
                    for (int i = 0; i < chaine.Length; i++)
                    {
                        if (cChaine[i]==' '&&cChaine[i+1]!=' ')
                        {
                            nmbrDeMots++;
                        }
                    }
                    Console.Write("Le nombre de mots de la chaine est: ");
                    Console.WriteLine(nmbrDeMots);
                    Console.WriteLine("frappez une touche pour revenir au menu ");
                    Console.ReadKey();
                }
            } while (choix > 0 && choix < 4);
        }
    }
}
