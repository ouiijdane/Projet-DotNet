﻿using System;

namespace TP1_EX2
{
    class Program
    {
        static void Main(string[] args)
        {
            string ligne = " ";
            int[,] matrice = { { 1, 3, 4, 6, 10 }, { 5, 8, 9, 4, 6 }, { 5, 14, 6, 7, 8 }, { 4, 5, 7, 6, 2 }, { 1, 5, 8, 7, 64 } };
            for (int i=0;i<5; i++)
            {
                ligne = " ";
                for(int j=0;j<5;j++)
                {
                    ligne += matrice[i, j].ToString()+" ";
                } 
                Console.WriteLine(ligne);
            }
            
        }
    }
}
