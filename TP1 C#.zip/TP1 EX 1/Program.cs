﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1_EX_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string type;   saisir le type de votre equation (+,-,*,/ ou %)
            Console.WriteLine("entrez le premier entier");
           int n1=int.Parse(Console.ReadLine());
            Console.WriteLine("entrez le deuxieme entier");
            int n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("entrez l'ndice d'operation" +
                " 1: addition " +
                " 2: soustraction " +
                " 3: multiplication " +
                " 4: division " +
                " 5: modulo ");
            int n3 = int.Parse(Console.ReadLine());
            if (n3 == 1)
            {
                n3 = n1 + n2;
                Console.WriteLine(n3);
            }
            else if (n3 == 2)
            {
                n3 = n1 - n2;
                Console.WriteLine(n3);
            }
            else if (n3 == 3)
            {
                n3 = n1 * n2;
                Console.WriteLine(n3);
            }
            else if (n3 == 4)
            {
                n3 = n1 / n2;
                Console.WriteLine(n3);
            }
            else if (n3 == 5)
            {
                n3 = n1 % n2;
                Console.WriteLine(n3);
            }
            else
                Console.WriteLine("erreur");
            Console.ReadLine();
        }
    }
}
